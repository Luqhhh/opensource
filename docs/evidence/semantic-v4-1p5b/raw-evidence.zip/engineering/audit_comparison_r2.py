"""Independently recount saved benchmark reports after the comparison finishes."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root))
from exampleproof.benchmark import score_benchmark

experiment = root / "artifacts" / "semantic-v4-live-1p5b-r2"
summary = json.loads((experiment / "summary.json").read_text())
protocol = json.loads((experiment / "protocol.json").read_text())
assert summary["complete"] and summary["error"] is None
assert len(summary["cells"]) == len(protocol["seeds"]) * len(protocol["projects"]) * 2


def inventory(directory):
    return {path.relative_to(directory).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(directory.rglob("*")) if path.is_file()}


assert inventory(experiment / "implementation") == protocol["implementation_sha256"]
for project in protocol["projects"]:
    assert inventory(experiment / "inputs" / project["name"]) == project["input_sha256"]

groups, cases = {}, {}
for policy in protocol["policies"]:
    counts, outcomes = Counter(), Counter()
    seen = set()
    for cell in summary["cells"]:
        if cell["policy"] != policy:
            continue
        key = (cell["seed"], cell["policy"], cell["project"])
        assert key not in seen
        seen.add(key)
        directory = experiment / "runs" / str(cell["seed"]) / policy / cell["project"]
        benchmark = json.loads((directory / "benchmark.json").read_text())
        baseline, repaired, patched = [json.loads((directory / phase / "report.json").read_text())
                                       for phase in ("baseline", "repair", "patched")]
        computed = score_benchmark(benchmark["manifest"], baseline, repaired, patched)
        assert benchmark["mode"] == "live_model" and benchmark["model"] == protocol["model"]
        assert computed == benchmark["metrics"] == cell["metrics"]
        assert computed["evaluation_complete"] and computed["baseline_valid"]
        counts["case_runs"] += computed["expected_failures"]
        counts["confirmed_repairs"] += computed["patch_confirmed_repairs"]
        counts["healthy_preserved"] += computed["healthy_preserved"]
        counts["healthy_controls"] += computed["healthy_controls"]
        for result in repaired["results"]:
            assert len(result["attempts"]) <= protocol["max_attempts"]
            for attempt in result["attempts"]:
                outcomes[attempt["status"]] += 1
                proposal = attempt["proposal"]
                if proposal is not None:
                    assert proposal["provider"] == "ollama" and proposal["model"] == protocol["model"]
                evidence = proposal["inference_evidence"] if proposal else attempt["inference_evidence"]
                assert evidence is not None
                request = evidence["request"]
                assert request["model"] == protocol["model"] and request["stream"] is False
                for option in ("temperature", "num_ctx", "num_predict", "repeat_penalty"):
                    assert request["options"][option] == protocol["options"][option]
                assert request["options"]["seed"] == (cell["seed"] + attempt["number"] - 1) % 2**31
                if policy in {"semantic-v3", "semantic-v4"}:
                    prompt = json.loads(request["prompt"])
                    expected_format = ["choice", "rationale"] if "repair_choices" in prompt else ["edits", "rationale"]
                    assert request["format"]["required"] == (expected_format if policy == "semantic-v4" else ["code", "rationale"])
                    prompt = json.loads(request["prompt"])
                    assert sum(len(key) + len(value) for key, value in prompt["sources"].items()) <= 4800
                    assert len(json.dumps(prompt.get("source_api_headers", {}), ensure_ascii=False)) <= 1200
                    for location, header in prompt.get("source_api_headers", {}).items():
                        filename, span = location.rsplit(":", 1)
                        start, end = map(int, span.split("-"))
                        source = experiment / "inputs" / cell["project"] / filename
                        assert header["signature"] == "".join(source.read_bytes().decode("utf-8").splitlines(keepends=True)[start - 1:end])
                else:
                    assert request["format"] == "json"
                if policy == "semantic-v4":
                    original = result["example"]["code"]
                    lines = original.splitlines(keepends=True)
                    if "edit_lines" in prompt:
                        assert prompt["edit_lines"] == {str(i): line.removesuffix("\n").removesuffix("\r") for i, line in enumerate(lines, 1)}
                    else:
                        assert len(json.dumps(prompt["repair_choices"], ensure_ascii=False)) <= 1200
                        assert request["format"]["properties"]["choice"]["enum"] == [choice["id"] for choice in prompt["repair_choices"]]
                    if proposal is not None:
                        raw = json.loads(evidence["response"]["response"])
                        if "repair_choices" in prompt:
                            selected = next(choice for choice in prompt["repair_choices"] if choice["id"] == raw["choice"])
                            raw = selected["edit"]
                        assert 1 <= len(raw["edits"]) <= 8
                        changes = {edit["line"]: edit["replacement"] for edit in raw["edits"]}
                        assert len(changes) == len(raw["edits"])
                        expected = "".join((changes[i].removesuffix("\n") + ("\n" if line.endswith("\n") else "") if changes[i] else "")
                                           if i in changes else line for i, line in enumerate(lines, 1))
                        assert expected == proposal["code"]
                counts["inference_requests"] += 1
        for row in computed["cases"]:
            if row["expected_before"] == "checked":
                assert row["repair_status"] == row["patched_status"] == "checked" and row["attempts"] == 0
            else:
                key = cell["project"] + "/" + row["id"]
                cases.setdefault(key, {}).setdefault(policy, {})[str(cell["seed"])] = (
                    row["repair_status"] == "verified_repair" and row["patched_status"] == "checked")
    for field in ("case_runs", "confirmed_repairs", "healthy_preserved", "inference_requests"):
        assert counts[field] == summary["groups"][policy][field]
    assert counts["confirmed_repairs"] / counts["case_runs"] == summary["groups"][policy]["repair_rate"]
    groups[policy] = {**counts, "attempt_statuses": dict(outcomes)}

assert len(cases) == summary["independent_failure_cases"]
model_root = root / "artifacts" / "local-runtime" / "models"
manifest = model_root / "manifests" / "registry.ollama.ai" / "library" / "qwen2.5-coder" / "1.5b"
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == protocol["model_metadata"]["model"]["digest"]
content = json.loads(manifest.read_text())
model_files = []
for layer in (content["config"], *content["layers"]):
    path = model_root / "blobs" / layer["digest"].replace(":", "-")
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for data in iter(lambda: source.read(4 * 1024 * 1024), b""):
            digest.update(data)
    assert digest.hexdigest() == layer["digest"][7:] and path.stat().st_size == layer["size"]
    model_files.append({"digest": layer["digest"], "measured_sha256": digest.hexdigest(), "size": path.stat().st_size})

record = {"complete": True, "groups": groups, "cases": cases, "model_files": model_files,
          "scope": "Recounted saved live 1.5B development-regression reports; no new inference or candidate execution."}
(experiment / "audit.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"complete": True, "groups": groups}, ensure_ascii=False), flush=True)
